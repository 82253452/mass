import Taro, {Component} from '@tarojs/taro'
import {View} from '@tarojs/components'
import {List} from '../components/list'
import './index.scss'

export default class ListPage extends Component {


  constructor() {
    super(...arguments)
    this.state = {
      type: '',
    }
  }

  componentWillMount() {
    if (this.$router.params.title) {
      Taro.setNavigationBarTitle({title: this.$router.params.title})
    }
    if (this.$router.params.type) {
      this.setState({type: this.$router.params.type});
    }
  }

  componentDidMount() {
  }

  componentWillUnmount() {
  }

  componentDidShow() {
  }

  componentDidHide() {
  }

  render() {
    return (
      <View className='main'>
        <List type={this.state.type}></List>
      </View>
    )
  }
}

