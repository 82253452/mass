import Taro, {Component} from '@tarojs/taro'
import {View, SwiperItem, Swiper, Image} from '@tarojs/components'
import './index.scss'

export default class ScrollImg extends Component {

  config = {
    navigationBarTitleText: '首页',
    component: true
  }

  static defaultProps = {
    autoplay: true,
    indicatorDots: true,
    imgs: []
  }

  constructor() {
    super(...arguments)
    this.state = {}
  }


  componentWillMount() {
  }

  componentDidMount() {
  }

  componentWillUnmount() {
  }

  componentDidShow() {
  }

  componentDidHide() {
  }

  render() {
    let {autoplay, indicatorDots, imgs} = this.props
    let item = imgs.map((obj, index) => <SwiperItem key={index}>
      <Image className='item' src={obj.src}/>
    </SwiperItem>)
    return (
      <Swiper
        className='main'
        indicatorColor='#999'
        indicatorActiveColor='#333'
        indicatorDots={indicatorDots}
        autoplay={autoplay}>
        {item}
      </Swiper>
    )
  }
}

