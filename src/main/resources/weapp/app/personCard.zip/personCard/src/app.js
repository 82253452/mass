import Taro, {Component} from '@tarojs/taro'
import Index from './pages/index'
import './app.scss'

class App extends Component {

  config = {
    pages: [
      'pages/index/index',
      'pages/login/login',
      'pages/List/index',
      'pages/center/index',
      'pages/about/index',
      'pages/detail/index',
    ],
    window: {
      backgroundTextStyle: 'light',
      navigationBarBackgroundColor: '#fff',
      navigationBarTitleText: 'WeChat',
      navigationBarTextStyle: 'black'
    },

  }

  componentWillMount() {

  }

  componentDidMount() {
  }

  componentDidShow() {

  }

  componentDidHide() {
  }

  componentCatchError() {
  }

  render() {
    return (
      <Index/>
    )
  }
}

Taro.render(<App/>, document.getElementById('app'))
