import Taro, {Component} from '@tarojs/taro'
import {View, Text} from '@tarojs/components'
import './index.scss'

export default class Navigation extends Component {


  static defaultProps = {
    data: {}
  }

  constructor() {
    super(...arguments)
    this.state = {
    }
  }

  componentWillMount() {
  }

  componentDidMount() {
  }

  componentWillUnmount() {
  }

  componentDidShow() {
  }

  componentDidHide() {
  }

  toList(title,type) {
      Taro.navigateTo({url: '/pages/List/index?title=' + title+'&type='+type})
  }
  toCenter() {
    Taro.navigateTo({url: '/pages/center/index'})
  }

  toAbout() {
    Taro.navigateTo({url: '/pages/about/index'})
  }

  render() {
    let {data} = this.props
    return (
      <View className='main'
            style="background:url({{data.bgImage}}) no-repeat;background-size:100% 100%;">
        <View className="content">
          <View onClick={this.toList.bind(this, '产品介绍','产品介绍')} className="tabar">
            <Text>产品介绍</Text>
          </View>
          <View onClick={this.toList.bind(this, '案例展示','案例展示')}  className="tabar">
            <Text>案例展示</Text>
          </View>
          <View onClick={this.toList.bind(this, '新闻中心','新闻中心')}  className="tabar">
            <Text>新闻中心</Text>
          </View>
          <View onClick={this.toList.bind(this, '欢迎加入','欢迎加入')} className="tabar">
            <Text>欢迎加入</Text>
          </View>
          <View onClick={this.toCenter} className="tabar">
            <Text>客服电话</Text>
          </View>
          <View onClick={this.toAbout} className="tabar">
            <Text>关于我们</Text>
          </View>
        </View>

      </View>
    )
  }
}

