import {Component} from '@tarojs/taro'
import Navigation from '../components/Navigation/index'
import {getG} from '../../utils/globalData'

export default class Index extends Component {

  config = {
    navigationBarTitleText: '首页',
  }

  constructor() {
    super(...arguments)
    this.state = {
      data: {
        bgImage: "http://images.fast4ward.cn/FtciafEqVCExhOX_xOW17sj7Bi9p"
      }
    }
  }

  componentWillMount() {
    let pageData = getG('pageData');
    if (pageData) {
      this.setState({pageData: getG('pageData')[1]})
    }
  }

  componentDidMount() {

  }

  componentWillUnmount() {
  }

  componentDidShow() {

  }

  componentDidHide() {

  }

  testclick() {
  }

  render() {
    let {data} = this.state
    return (
      <Navigation data={data}></Navigation>
    )
  }
}

