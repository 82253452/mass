import Taro, {Component} from '@tarojs/taro'
import {View, Map, Text} from '@tarojs/components'
import './index.scss'

export default class center extends Component {

  config = {
    navigationBarTitleText: '联系我们',
  }

  constructor() {
    super(...arguments)
    const location = {
      latitude: 39.873195,
      longitude: 116.486554,
    }
    this.state = {
      ...location,
      markers: [
        {
          ...location
        }
      ]
    }
  }

  componentWillMount() {

  }

  componentDidMount() {
  }

  componentWillUnmount() {
  }

  componentDidShow() {
  }

  componentDidHide() {
  }

  render() {
    return (
      <View className='main'>
        <View>
          <Map className="map" markers={this.state.markers} longitude={this.state.longitude}
               latitude={this.state.latitude}>
          </Map>
        </View>
        <View className="content">
          <Text className="text">公司名称:&nbsp;&nbsp;</Text>
          <Text className="text">北京极速达科技有限公司</Text>
        </View>
        <View className="content">
          <Text className="text">地址:&nbsp;&nbsp;</Text>
          <Text className="text">北京市朝阳区</Text>
        </View>
        <View className="content">
          <Text className="text">QQ:&nbsp;&nbsp;</Text>
          <Text className="text">82253452</Text>
        </View>
        <View className="content">
          <Text className="text">手机:&nbsp;&nbsp;</Text>
          <Text className="text">15901320019</Text>
        </View>

      </View>
    )
  }
}

