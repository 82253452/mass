import Taro, {Component} from '@tarojs/taro'
import {View, Map, Text,Image} from '@tarojs/components'
import './index.scss'

export default class center extends Component {

  config = {
    navigationBarTitleText: '关于我们',
  }

  constructor() {
    super(...arguments)
    this.state = {

    }
  }

  componentWillMount() {

  }

  componentDidMount() {
  }

  componentWillUnmount() {
  }

  componentDidShow() {
  }

  componentDidHide() {
  }

  render() {
    return (
      <View className='main'>
        <Image className='image' src={'http://images.fast4ward.cn/o_1crjt23df1ms917km5s31j9i7bjh.jpg'}/>
      </View>
    )
  }
}

