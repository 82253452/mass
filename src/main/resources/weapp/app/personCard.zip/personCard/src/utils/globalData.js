const globalData = {
  appId:'wx261af1b9cee4273b',
}

export function setG(key, val) {
  globalData[key] = val
}

export function getG(key) {
  return globalData[key]
}

export function incG(key) {
  return ++globalData[key]
}
