import Taro from '@tarojs/taro'
import {LOGIN} from "./api"
import {getG, incG} from "./globalData"

const BASW = 'http://localhost:8082'
const TOKEN = 'token'
const FAILECOUNT = 'faileCount'

const fetch = (api, param) => {
  return new Promise((resolve, reject) => {
    let token = Taro.getStorageSync(TOKEN)
    let mustLogin = api.login
    if (mustLogin) {
      if (!token) {
        Taro.navigateTo({
          url: '/pages/login/login'
        })
        return
      }
    }
    Taro.request({
      url: BASW + api.url,
      data: {
        ...param,
        token: Taro.getStorageSync(TOKEN)
      },
      method: api.method,
      header: {
        'content-type': 'application/x-www-form-urlencoded'
      },
      success: (res) => {
        if (res.data.code === 3000) {
          console.error('连接失败重试')
          incG(FAILECOUNT)
          if (getG(FAILECOUNT) == 2) {
            console.error('连重试失败')
            reject('重试失败')
            return;
          }
          // app.globalData.faileCount++
          // if (app.globalData.faileCount == 2) {
          //   return;
          // }
          loginNew(() => {
            fetch(api, param)
          })
        }
        resolve(res.data.data)
      },
      fail: (err) => {
        reject(err)
      }
    })
  });

}


const loginNew = (res, callback) => {
  Taro.login({
    success(resp) {
      if (resp.code) {
        postLogin(resp.code, res.detail, callback)
      } else {
        // 否则弹窗显示，showToast需要封装
        showToast()
      }
    },
    fail() {
      showToast()
    }
  })
}


// 开发者服务端登录
const postLogin = (code, res, callback) => {
  console.log('开始登录')
  fetch(LOGIN, {
    code: code,
    iv: res.iv,
    encryptedData: res.encryptedData,
    appId: getG('appId')
  }).then((data) => {
    Taro.setStorageSync(TOKEN, data.token)
    callback && callback()
  })
}

// 显示toast弹窗
function showToast(content = '登录失败，请稍后再试') {
  Taro.showToast({
    title: content,
    icon: 'none'
  })
}

// 判断是否登录
function isLogin(callback) {
  let token = Taro.getStorageSync(TOKEN)
  if (token) {
    callback && callback()
  } else {
    // 如果没有登录态，弹窗提示一键登录
    // showLoginModal()
    Taro.navigateTo({
      url: './center'
    })
  }
}

// 接口调用失败处理，
function handleError(res, callback) {
  // 规定-3041和-3042分别代表未登录和登录态失效
  if (res.code == -3041 || res.code == -3042) {
    // 弹窗提示一键登录
    showLoginModal()
  } else if (res.msg) {
    // 弹窗显示错误信息
    showToast(res.msg)
  }
}

// 显示一键登录的弹窗
function showLoginModal() {
  Taro.showModal({
    title: '提示',
    content: '你还未登录，登录后可获得完整体验 ',
    confirmText: '一键登录',
    success(res) {
      // 点击一键登录，去授权页面
      if (res.confirm) {
        Taro.navigateTo({
          url: '/pages/login/login',
        })
      }
    }
  })
}

export {
  fetch,
  isLogin,
  loginNew
}
