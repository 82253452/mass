import Taro, {Component} from '@tarojs/taro'
import {View, Button} from '@tarojs/components'
import {loginNew} from "../../utils/fetch";
import loginBg from '../../image/loginbg.jpg'
import './login.scss'

export default class Login extends Component {
  config = {
    navigationBarTitleText: '登录'
  }
  getUserInfo = (res) => {
    loginNew(res, () => {
      Taro.navigateBack()
    })
  }


  render() {
    return (<View className="pagebox">
      <View className='cn'>
        <View className='img'>
          <image src={loginBg} mode='widthFix'></image>
        </View>
        <View className='title'>登录授权</View>
        <View className='text' style='padding-top:12rpx;'>看赛事、看美女、看酷车</View>
        <View className='text' style='padding-top:12rpx;'>这里应有尽有</View>
        <View className='button'>立即登录
          <Button openType="getUserInfo" onGetUserInfo={this.getUserInfo} className="save-btn">立即登录</Button>
        </View>
      </View>
    </View>)
  }
}

