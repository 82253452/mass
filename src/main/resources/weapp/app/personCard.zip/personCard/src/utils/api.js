/*
* 登录接口
* */
export const LOGIN = {
  url: '/we/login',
  method: 'post'
}
/*
* 获取页面数据,然后缓存上 更新方案暂无
* */
export const PAGEINFO = {
  url: '/we/getByAppId',
  method: 'get',
}
/*
* 获取文章列表
* */
export const ARTICLES = {
  url: '/we/getArticleList',
  method: 'get',
}

/*
* 获取文章列表
* */
export const ARTICLE_DETAIL = {
  url: '/we/getArticleDetail',
  method: 'get',
}
