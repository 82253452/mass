import {Component} from '@tarojs/taro'
import {Text, View} from '@tarojs/components'
import {ARTICLE_DETAIL} from '../../utils/api'
import {fetch} from '../../utils/fetch'
import {parseTime} from '../../utils/util'
import wxParse from '../../thirdPart/wxParse/wxParse'
import './index.scss'
import './wxParse.scss'


export default class detail extends Component {

  config = {
    navigationBarTitleText: '详情',
  }

  constructor() {
    super(...arguments)
    this.state = {
      data: {},
    }
  }

  componentWillMount() {
    if (this.$router.params.id) {
      fetch(ARTICLE_DETAIL, {id: this.$router.params.id}).then(resp => {
        if (resp) {
          this.setState({data: resp.data});
          wxParse.wxParse('article', 'html', resp.data.content, this.$scope, 0);
          console.log(this.state.article)
        }
      })

    }
  }

  componentDidMount() {
  }

  componentWillUnmount() {
  }

  componentDidShow() {
  }

  componentDidHide() {
  }

  parseDate(time) {
    return parseTime(time)
  }


  render() {
    let {data} = this.state
    return (
      <View className='main'>
        <View className='top'>
          <View>
            <Text className='title'>{data.title}</Text>
          </View>
          <View className="center">
            <Text className='time'>时间：{this.parseDate(data.ctime)}</Text>
            <Text className='read'>阅读量：{data.readNum?data.readNum:0}</Text>
          </View>
        </View>
        <View className='content'>
          {/*{data.content}*/}
          <import src='../../thirdPart/wxParse/wxParse.wxml' />
          <template is='wxParse' data='{{wxParseData:article.nodes}}'/>
        </View>
      </View>
    )
  }
}

