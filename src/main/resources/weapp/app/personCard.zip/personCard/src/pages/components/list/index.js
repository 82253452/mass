import Taro, {Component} from '@tarojs/taro'
import {View, Text, Image} from '@tarojs/components'
import {ARTICLES} from '../../../utils/api'
import {fetch} from '../../../utils/fetch'
import './index.scss'

export default class List extends Component {

  static defaultProps = {
    type: '',
  }

  constructor() {
    super(...arguments)
    this.state = {
      data: [],
    }
  }

  componentWillMount() {
    fetch(ARTICLES, {type: this.props.type}).then(res => {
      this.setState({
        data: res.data
      });
    })
  }

  componentDidMount() {
  }

  componentWillUnmount() {
  }

  componentDidShow() {
  }

  componentDidHide() {
  }

  toDetail(id) {
    Taro.navigateTo({url: '/pages/detail/index?id=' + id})
  }

  render() {
    let {data} = this.state
    let comList = data.map((obj, index) => {
      return <View key={index} className='block' onClick={this.toDetail.bind(this, obj.id)}>
        <Image src={obj.img} className='img'/>
        <View className='textView'>
          <Text>{obj.title}</Text>
        </View>
      </View>
    })
    return (
      <View className='main'>
        {comList}
      </View>
    )
  }
}

